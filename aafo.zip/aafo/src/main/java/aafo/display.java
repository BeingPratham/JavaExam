package aafo;

import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class display
 */
public class display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public display() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String driver="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost/demo";
		String usr="root";
		String pwd="";
		out.print("<a href='productlist'>productlist<a>");
		
		HttpSession session=request.getSession(false);
		if(session!=null)
		{
			out.print("<br>");
			out.print("welcome, "+session.getAttribute("username"));
			out.print("<a href='logout'>logout</a>");
		}
		
		
		try {
			
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url,usr,pwd);
			Statement st=con.createStatement();
			String query="select * from login1";
			ResultSet rs=st.executeQuery(query);
			out.print("<table>");
			while(rs.next()) {
				out.print("<tr><td>"+rs.getString(1)+"</td>"
						+ "<td>"+rs.getString(2)+"</td>"
						+ "<td>"+rs.getString(3)+"</td>"
						+ "<td>"+rs.getString(4)+"</td>"
						+ "<td>"+rs.getString(5)+"</td>"
						+ "<td><a href='delete?id="+rs.getString(1)+"'>delete</a></td>"
						+ "<td><a href='updateform?id="+ rs.getString(1)+"'>update</a></td></tr>");
			}
			out.print("</table>");
			
	
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
