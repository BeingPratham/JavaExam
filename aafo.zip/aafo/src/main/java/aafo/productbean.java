package aafo;  

public class productbean {

	private int id;

	public int getid() {
		return id;
	}

	public void setid(int id) {
		this.id = id;
	}
	
	}

