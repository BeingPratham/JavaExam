package sakshi;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class updateformservlet
 */
public class updateformservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateformservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");

		String id=request.getParameter("id");
		out.print("<form action='updateservlet'><table>"
		+"<tr><td>Name:</td><td><input type='text' name='username'></td></tr>"
		+"<tr><td>Password:</td><td><input type='text' name='password'></td></tr>"
		+"<tr><td>Email:</td><td><input type='text' name='email'></td></tr>"
		+"<tr><td>City:</td><td><input type='text' name='city'></td></tr>"
		+"<tr><td></td><td><input type='submit' value='update'></td></tr>"
		+"<tr><td></td><td><input type='hidden' name='id' value='"+id+"'></td></tr></table></form>");
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
