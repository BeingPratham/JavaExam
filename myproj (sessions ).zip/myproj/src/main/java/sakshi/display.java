package sakshi;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class display
 */
public class display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public display() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String username=request.getParameter("unm");
		String password=request.getParameter("pswd");
		//register driver

		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://128.66.203.247/exam21","exam21","sumo@123");
		String query="select * from login where username=? and password=?";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1,username);
		ps.setString(2,password);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{

			/*Cookie cookie=new Cookie("username",Unm);
			Cookie c2=new Cookie("password",pswd);
			cookie.setMaxAge(10000);
			response.addCookie(cookie);
			response.addCookie(c2);
			 */
			HttpSession session=request.getSession(true);
			session.setAttribute("username", username );
			RequestDispatcher rd=request.getRequestDispatcher("displayservlet");
			rd.forward(request, response);		
		}
		else
		{
		    out.print("<br>Username or Password is not valid");
		    RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.include(request, response);
		}
		}
		catch (Exception e)  {
		e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
