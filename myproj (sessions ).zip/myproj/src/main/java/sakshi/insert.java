package sakshi;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class insert
 */
public class insert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insert() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String ID=request.getParameter("id");
		String username=request.getParameter("unm");
		String password=request.getParameter("pswd");
		String email=request.getParameter("em");
		String city=request.getParameter("city");
		out.print("<h1>hello.</h1><br>YOUR ID: "+ID);
		out.print("hello<h1>"+username+"</h1>");
		out.print("<br>password is:"+password);
		out.print("YOUR EMAIL: "+email);
		out.print("YOUR CITY: "+city);
		//register driver

		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://128.66.203.247/exam21","exam21","sumo@123");
		String query="insert into login (ID,username,password,email,city)" + "values(?,?,?,?,?)";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1,ID);
		ps.setString(2,username);
		ps.setString(3,password);
		ps.setString(4,email);
		ps.setString(5,city);
		int i=ps.executeUpdate();
		out.print(i+"record inserted");
		out.print("<br><a href='display'>display all records</a>");
		}
		catch (Exception e)  {
		e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
